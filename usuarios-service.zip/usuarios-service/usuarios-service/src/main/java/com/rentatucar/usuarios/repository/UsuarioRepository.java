package com.rentatucar.usuarios.repository;

import com.rentatucar.usuarios.model.Usuario;
import com.rentatucar.usuarios.model.Rol;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    List<Usuario> findByRol(Rol rol);
    Optional<Usuario> findByEmail(String email);
}
