package com.rentatucar.usuarios.model;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.persistence.*;

@Schema(description = "Entidad que representa un usuario del sistema")
@Entity
@Table(name = "usuarios")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "ID único del usuario", example = "1")
    private Long id;

    @Column(nullable = false)
    @Schema(description = "Nombre completo del usuario", example = "Raúl Saldías")
    private String nombre;

    @Column(nullable = false, unique = true)
    @Schema(description = "Correo electrónico del usuario", example = "raul@rentatucar.cl")
    private String email;

    @Column(nullable = false)
    @Schema(description = "Contraseña del usuario", example = "123456")
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Schema(description = "Rol del usuario en el sistema", example = "ARRENDADOR")
    private Rol rol;

    // Constructores
    public Usuario() {
    }

    public Usuario(Long id, String nombre, String email, String password, Rol rol) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.password = password;
        this.rol = rol;
    }

    // Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }
}
