package com.rentatucar.usuarios.controller;

import com.rentatucar.usuarios.model.Usuario;
import com.rentatucar.usuarios.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@Tag(name = "Usuarios", description = "Operaciones CRUD sobre usuarios del sistema")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @Operation(summary = "Obtener todos los usuarios")
    @ApiResponse(responseCode = "200", description = "Lista de usuarios")
    @GetMapping
    public List<Usuario> findAll() {
        return usuarioService.findAll();
    }

    @Operation(summary = "Obtener usuario por ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Usuario encontrado"),
            @ApiResponse(responseCode = "404", description = "Usuario no existe")
    })
    @GetMapping("/{id}")
    public Usuario findById(
            @Parameter(description = "ID del usuario", required = true)
            @PathVariable Long id) {
        return usuarioService.findById(id);
    }

    @Operation(summary = "Crear nuevo usuario")
    @ApiResponse(responseCode = "200", description = "Usuario creado")
    @PostMapping
    public Usuario create(
            @RequestBody(description = "Datos del nuevo usuario", required = true,
                    content = @Content(schema = @Schema(implementation = Usuario.class),
                            examples = @ExampleObject(name = "UsuarioEjemplo", value = """
                {
                  "nombre": "Laura",
                  "email": "laura@rentatucar.cl",
                  "password": "abc123",
                  "rol": "ARRENDADOR"
                }
            """)))
            @org.springframework.web.bind.annotation.RequestBody Usuario usuario) {
        return usuarioService.save(usuario);
    }

    @Operation(summary = "Actualizar usuario existente")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Usuario actualizado"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @PutMapping("/{id}")
    public Usuario update(
            @Parameter(description = "ID del usuario a actualizar", required = true)
            @PathVariable Long id,
            @RequestBody(description = "Datos actualizados", required = true,
                    content = @Content(schema = @Schema(implementation = Usuario.class)))
            @org.springframework.web.bind.annotation.RequestBody Usuario usuario) {

        usuario.setId(id);
        return usuarioService.save(usuario);
    }

    @Operation(summary = "Eliminar usuario por ID")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Usuario eliminado"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID del usuario", required = true)
            @PathVariable Long id) {
        usuarioService.delete(id);
        return ResponseEntity.ok().build();
    }
}
