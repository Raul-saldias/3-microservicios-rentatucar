package com.rentatucar.usuarios.swaggerconfig;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class Config {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("RentuCar Usuarios")
                        .version("1.0")
                        .description(" API 2025 Renta de Vehiculos Particulares"));



    }
}
