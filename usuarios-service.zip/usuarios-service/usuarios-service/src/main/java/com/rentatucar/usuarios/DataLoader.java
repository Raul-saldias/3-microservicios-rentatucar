package com.rentatucar.usuarios;

import com.rentatucar.usuarios.model.Rol;
import com.rentatucar.usuarios.model.Usuario;
import com.rentatucar.usuarios.repository.UsuarioRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Profile("dev") // Se ejecuta solo en el perfil de desarrollo
@Component
public class DataLoader implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;

    public DataLoader(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println(" Iniciando carga de datos con Faker...");

        // Limpia la tabla de usuarios antes de insertar
        usuarioRepository.deleteAll();

        Faker faker = new Faker();
        Set<String> emailsGenerados = new HashSet<>();

        for (int i = 0; i < 10; i++) {
            String email;
            do {
                email = faker.internet().emailAddress();
            } while (!emailsGenerados.add(email));

            Usuario u = new Usuario();
            u.setNombre(faker.name().fullName());
            u.setEmail(email);
            u.setPassword("123456"); // clave fija para pruebas
            u.setRol(Rol.values()[i % Rol.values().length]);

            usuarioRepository.save(u);
        }

        System.out.println("✅ Se insertaron 10 usuarios de prueba exitosamente.");
    }
}
