package com.rentatucar.usuarios.model;

public enum Rol {
    ADMINISTRADOR,
    ARRENDATARIO,
    ARRENDADOR
}
