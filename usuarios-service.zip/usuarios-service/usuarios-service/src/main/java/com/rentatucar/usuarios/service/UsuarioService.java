package com.rentatucar.usuarios.service;

import com.rentatucar.usuarios.model.Rol;
import com.rentatucar.usuarios.model.Usuario;
import com.rentatucar.usuarios.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Obtener todos los usuarios
    public List<Usuario> findAll() {
        return usuarioRepository.findAll();
    }

    // Buscar por ID
    public Usuario findById(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + id));
    }

    // Crear o actualizar
    public Usuario save(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    // Eliminar por ID
    public void delete(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new RuntimeException("Usuario no encontrado para eliminar con ID: " + id);
        }
        usuarioRepository.deleteById(id);
    }

    // Buscar por rol
    public List<Usuario> findByRol(String rol) {
        try {
            Rol rolEnum = Rol.valueOf(rol.toUpperCase());
            return usuarioRepository.findByRol(rolEnum);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Rol inválido: " + rol);
        }
    }

    // Buscar por email exacto
    public Usuario findByEmail(String email) {
        return usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con email: " + email));
    }

    // Contar usuarios
    public Long contar() {
        return usuarioRepository.count();
    }
}
