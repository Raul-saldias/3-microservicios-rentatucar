package com.rentatucar.usuarios.controller;

import com.rentatucar.usuarios.assembler.UsuarioModelAssembler;
import com.rentatucar.usuarios.model.Usuario;
import com.rentatucar.usuarios.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/usuarios")
public class UsuarioControllerV2 {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private UsuarioModelAssembler assembler;

    @GetMapping
    public CollectionModel<EntityModel<Usuario>> findAll() {
        List<EntityModel<Usuario>> usuarios = usuarioService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(usuarios,
                linkTo(methodOn(UsuarioControllerV2.class).findAll()).withSelfRel());
    }

    @GetMapping("/{id}")
    public EntityModel<Usuario> findById(@PathVariable Long id) {
        Usuario usuario = usuarioService.findById(id);
        return assembler.toModel(usuario);
    }

    @GetMapping("/rol/{rol}")
    public CollectionModel<EntityModel<Usuario>> findByRol(@PathVariable String rol) {
        List<EntityModel<Usuario>> usuarios = usuarioService.findByRol(rol).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(usuarios,
                linkTo(methodOn(UsuarioControllerV2.class).findByRol(rol)).withSelfRel());
    }

    @GetMapping("/correo/{email}")
    public EntityModel<Usuario> findByEmail(@PathVariable String email) {
        Usuario usuario = usuarioService.findByEmail(email);
        return assembler.toModel(usuario);
    }

    @GetMapping("/contar")
    public EntityModel<Long> contarUsuarios() {
        Long total = usuarioService.contar();
        return EntityModel.of(total,
                linkTo(methodOn(UsuarioControllerV2.class).contarUsuarios()).withSelfRel(),
                linkTo(methodOn(UsuarioControllerV2.class).findAll()).withRel("usuarios"));
    }
}
