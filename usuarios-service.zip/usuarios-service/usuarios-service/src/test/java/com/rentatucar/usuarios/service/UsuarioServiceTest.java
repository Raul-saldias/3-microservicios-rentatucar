package com.rentatucar.usuarios.service;

import com.rentatucar.usuarios.model.Rol;
import com.rentatucar.usuarios.model.Usuario;
import com.rentatucar.usuarios.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario(1L, "Raúl", "raul@rentatucar.cl", "123456", Rol.ADMINISTRADOR);
    }

    @Test
    public void testFindAll() {
        when(usuarioRepository.findAll()).thenReturn(List.of(usuario));

        List<Usuario> usuarios = usuarioService.findAll();

        assertNotNull(usuarios);
        assertEquals(1, usuarios.size());
        assertEquals("Raúl", usuarios.get(0).getNombre());
        assertEquals(Rol.ADMINISTRADOR, usuarios.get(0).getRol());
    }

    @Test
    public void testFindById() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

        Usuario resultado = usuarioService.findById(1L);

        assertNotNull(resultado);
        assertEquals("Raúl", resultado.getNombre());
        assertEquals("123456", resultado.getPassword());
        assertEquals(Rol.ADMINISTRADOR, resultado.getRol());
    }

    @Test
    public void testSave() {
        Usuario nuevo = new Usuario(null, "Andrea", "andrea@rentatucar.cl", "654321", Rol.ARRENDATARIO);
        Usuario guardado = new Usuario(2L, "Andrea", "andrea@rentatucar.cl", "654321", Rol.ARRENDATARIO);

        when(usuarioRepository.save(nuevo)).thenReturn(guardado);

        Usuario resultado = usuarioService.save(nuevo);

        assertNotNull(resultado);
        assertEquals("Andrea", resultado.getNombre());
        assertEquals("andrea@rentatucar.cl", resultado.getEmail());
        assertEquals(Rol.ARRENDATARIO, resultado.getRol());
    }

    @Test
    public void testDelete() {
        doNothing().when(usuarioRepository).deleteById(1L);

        usuarioService.delete(1L);

        verify(usuarioRepository, times(1)).deleteById(1L);
    }
}
