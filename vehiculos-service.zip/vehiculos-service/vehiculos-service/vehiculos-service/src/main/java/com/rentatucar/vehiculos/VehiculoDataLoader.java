package com.rentatucar.vehiculos;

import com.rentatucar.vehiculos.model.Vehiculo;
import com.rentatucar.vehiculos.service.VehiculoService;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

@Profile("dev")
@Component
public class VehiculoDataLoader implements CommandLineRunner {

    private final VehiculoService vehiculoService;

    public VehiculoDataLoader(VehiculoService vehiculoService) {
        this.vehiculoService = vehiculoService;
    }

    @Override
    public void run(String... args) {
        Faker faker = new Faker(new Locale("es"));
        Random random = new Random();
        Set<String> placasGeneradas = new HashSet<>();

        if (vehiculoService.obtenerTodos().isEmpty()) {
            int generados = 0;
            while (generados < 20) {
                String placa = faker.bothify("???###").toUpperCase();
                if (placasGeneradas.contains(placa)) continue;

                Vehiculo vehiculo = new Vehiculo();
                vehiculo.setMarca(faker.company().name());
                vehiculo.setModelo(faker.ancient().god());
                vehiculo.setAnio(faker.number().numberBetween(2015, 2024));
                vehiculo.setPrecioPorDia(faker.number().randomDouble(2, 20000, 80000));
                vehiculo.setPlacaPatente(placa);
                vehiculo.setEstado("DISPONIBLE");

                try {
                    vehiculoService.registrarVehiculo(vehiculo);
                    placasGeneradas.add(placa);
                    generados++;
                } catch (RuntimeException e) {
                    System.err.println("⚠️ Error al registrar vehículo con placa " + placa + ": " + e.getMessage());
                }
            }
            System.out.println("✅ Vehículos de prueba generados exitosamente.");
        } else {
            System.out.println("ℹ️ Ya existen vehículos registrados. No se generaron nuevos.");
        }
    }
}