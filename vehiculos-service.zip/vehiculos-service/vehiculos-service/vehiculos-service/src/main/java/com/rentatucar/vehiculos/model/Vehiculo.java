package com.rentatucar.vehiculos.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

@Entity
@Table(name = "vehiculos")
@Data
public class Vehiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "La placa patente es obligatoria")
    @Column(nullable = false, unique = true)
    private String placaPatente;

    @NotBlank(message = "La marca es obligatoria")
    private String marca;

    @NotBlank(message = "El modelo es obligatorio")
    private String modelo;

    @Min(value = 2000, message = "El año debe ser mayor o igual a 2000")
    @Max(value = 2025, message = "El año debe ser menor o igual a 2025")
    private int anio;

    @NotNull(message = "El precio por día es obligatorio")
    @DecimalMin(value = "0.0", inclusive = false, message = "El precio debe ser mayor que 0")
    private Double precioPorDia;

    @NotBlank(message = "El estado es obligatorio")
    private String estado;
}