package com.rentatucar.vehiculos.assembler;

import com.rentatucar.vehiculos.controller.VehiculoControllerV2;
import com.rentatucar.vehiculos.model.Vehiculo;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class VehiculoModelAssembler implements RepresentationModelAssembler<Vehiculo, EntityModel<Vehiculo>> {

    @Override
    public EntityModel<Vehiculo> toModel(Vehiculo v) {
        return EntityModel.of(v,
                linkTo(methodOn(VehiculoControllerV2.class).obtenerPorId(v.getId())).withSelfRel(),
                linkTo(methodOn(VehiculoControllerV2.class).listarTodos()).withRel("todos"),
                linkTo(methodOn(VehiculoControllerV2.class).porPlaca(v.getPlacaPatente())).withRel("por-placa"),
                linkTo(methodOn(VehiculoControllerV2.class).porEstado(v.getEstado())).withRel("por-estado"),
                linkTo(methodOn(VehiculoControllerV2.class).porMarca(v.getMarca())).withRel("por-marca"),
                linkTo(methodOn(VehiculoControllerV2.class).porModelo(v.getModelo())).withRel("por-modelo"),
                linkTo(methodOn(VehiculoControllerV2.class).porAnio(v.getAnio())).withRel("por-anio"),
                linkTo(methodOn(VehiculoControllerV2.class).porPrecio(v.getPrecioPorDia())).withRel("por-precio")
        );
    }
}