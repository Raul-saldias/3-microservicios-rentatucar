package com.rentatucar.vehiculos.controller;

import com.rentatucar.vehiculos.model.Vehiculo;
import com.rentatucar.vehiculos.service.VehiculoService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vehiculos")
@Tag(name = "Vehículos", description = "CRUD y búsquedas sin HATEOAS")
public class VehiculoController {

    private final VehiculoService service;

    public VehiculoController(VehiculoService service) {
        this.service = service;
    }

    @PostMapping
    public Vehiculo crear(@Valid @RequestBody Vehiculo v) {
        return service.registrarVehiculo(v);
    }

    @GetMapping("/{id}")
    public Vehiculo obtenerPorId(@PathVariable Long id) {
        return service.obtenerPorId(id);
    }

    @GetMapping
    public List<Vehiculo> listarTodos() {
        return service.obtenerTodos();
    }

    @PutMapping("/{id}")
    public Vehiculo actualizar(@PathVariable Long id, @Valid @RequestBody Vehiculo v) {
        return service.actualizarVehiculo(id, v);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminarPorId(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/placa/{placa}")
    public Vehiculo buscarPorPlaca(@PathVariable String placa) {
        return service.buscarPorPlaca(placa);
    }

    @GetMapping("/estado/{estado}")
    public List<Vehiculo> buscarPorEstado(@PathVariable String estado) {
        return service.buscarPorEstado(estado);
    }

    @GetMapping("/marca/{marca}")
    public List<Vehiculo> buscarPorMarca(@PathVariable String marca) {
        return service.buscarPorMarca(marca);
    }

    @GetMapping("/modelo/{modelo}")
    public List<Vehiculo> buscarPorModelo(@PathVariable String modelo) {
        return service.buscarPorModelo(modelo);
    }

    @GetMapping("/anio/{anio}")
    public List<Vehiculo> buscarPorAnio(@PathVariable int anio) {
        return service.buscarPorAnio(anio);
    }

    @GetMapping("/precio/{precio}")
    public List<Vehiculo> buscarPorPrecio(@PathVariable Double precio) {
        return service.buscarPorPrecio(precio);
    }
}