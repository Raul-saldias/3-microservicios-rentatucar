package com.rentatucar.vehiculos.service;

import com.rentatucar.vehiculos.model.Vehiculo;
import com.rentatucar.vehiculos.repository.VehiculoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehiculoService {

    private final VehiculoRepository repo;

    public VehiculoService(VehiculoRepository repo) {
        this.repo = repo;
    }

    // Crear vehículo
    public Vehiculo registrarVehiculo(Vehiculo v) {
        repo.findByPlacaPatente(v.getPlacaPatente()).ifPresent(existing -> {
            throw new RuntimeException("Ya existe un vehículo con esta placa patente.");
        });
        return repo.save(v);
    }

    // Obtener vehículo por ID
    public Vehiculo obtenerPorId(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Vehículo no encontrado: ID " + id));
    }

    // Buscar por placa
    public Vehiculo buscarPorPlaca(String placa) {
        return repo.findByPlacaPatente(placa)
                .orElseThrow(() -> new RuntimeException("Vehículo no encontrado: Placa " + placa));
    }

    // Obtener todos
    public List<Vehiculo> obtenerTodos() {
        return repo.findAll();
    }

    // Buscar por estado
    public List<Vehiculo> buscarPorEstado(String estado) {
        return repo.findByEstado(estado);
    }

    // Buscar por marca
    public List<Vehiculo> buscarPorMarca(String marca) {
        return repo.findByMarca(marca);
    }

    // Buscar por modelo
    public List<Vehiculo> buscarPorModelo(String modelo) {
        return repo.findByModelo(modelo);
    }

    // Buscar por año
    public List<Vehiculo> buscarPorAnio(int anio) {
        return repo.findByAnio(anio);
    }

    // Buscar por precio
    public List<Vehiculo> buscarPorPrecio(Double precio) {
        return repo.findByPrecioPorDia(precio);
    }

    // Actualizar vehículo
    public Vehiculo actualizarVehiculo(Long id, Vehiculo datos) {
        Vehiculo v = obtenerPorId(id);
        v.setMarca(datos.getMarca());
        v.setModelo(datos.getModelo());
        v.setAnio(datos.getAnio());
        v.setPrecioPorDia(datos.getPrecioPorDia());
        v.setEstado(datos.getEstado());
        return repo.save(v);
    }

    // Eliminar por ID
    public void eliminarPorId(Long id) {
        Vehiculo v = obtenerPorId(id);
        repo.delete(v);
    }

    // Actualizar estado por placa
    public void actualizarEstadoVehiculo(String placa, String nuevoEstado) {
        Vehiculo v = buscarPorPlaca(placa);
        v.setEstado(nuevoEstado);
        repo.save(v);
    }

    // Eliminar por placa
    public boolean eliminarVehiculoPorPlaca(String placa) {
        Vehiculo v = buscarPorPlaca(placa);
        repo.delete(v);
        return true;
    }
}