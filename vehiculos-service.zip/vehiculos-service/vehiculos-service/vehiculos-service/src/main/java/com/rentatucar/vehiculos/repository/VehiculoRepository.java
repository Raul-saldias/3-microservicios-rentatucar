package com.rentatucar.vehiculos.repository;

import com.rentatucar.vehiculos.model.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {
    Optional<Vehiculo> findByPlacaPatente(String placaPatente);
    List<Vehiculo> findByEstado(String estado);
    List<Vehiculo> findByMarca(String marca);
    List<Vehiculo> findByModelo(String modelo);
    List<Vehiculo> findByAnio(int anio);
    List<Vehiculo> findByPrecioPorDia(Double precioPorDia);
}