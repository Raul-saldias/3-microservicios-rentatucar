package com.rentatucar.vehiculos.controller;

import com.rentatucar.vehiculos.assembler.VehiculoModelAssembler;
import com.rentatucar.vehiculos.model.Vehiculo;
import com.rentatucar.vehiculos.service.VehiculoService;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/vehiculos")
public class VehiculoControllerV2 {

    private final VehiculoService service;
    private final VehiculoModelAssembler assembler;

    public VehiculoControllerV2(VehiculoService service, VehiculoModelAssembler assembler) {
        this.service = service;
        this.assembler = assembler;
    }

    @PostMapping
    public EntityModel<Vehiculo> crear(@RequestBody Vehiculo v) {
        return assembler.toModel(service.registrarVehiculo(v));
    }

    @GetMapping("/{id}")
    public EntityModel<Vehiculo> obtenerPorId(@PathVariable Long id) {
        return assembler.toModel(service.obtenerPorId(id));
    }

    @GetMapping
    public CollectionModel<EntityModel<Vehiculo>> listarTodos() {
        return CollectionModel.of(service.obtenerTodos().stream().map(assembler::toModel).toList());
    }

    @PutMapping("/{id}")
    public EntityModel<Vehiculo> actualizar(@PathVariable Long id, @RequestBody Vehiculo v) {
        return assembler.toModel(service.actualizarVehiculo(id, v));
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminarPorId(id);
    }

    @GetMapping("/placa/{placa}")
    public EntityModel<Vehiculo> porPlaca(@PathVariable String placa) {
        return assembler.toModel(service.buscarPorPlaca(placa));
    }

    @GetMapping("/estado/{estado}")
    public CollectionModel<EntityModel<Vehiculo>> porEstado(@PathVariable String estado) {
        return CollectionModel.of(service.buscarPorEstado(estado).stream().map(assembler::toModel).toList());
    }

    @GetMapping("/marca/{marca}")
    public CollectionModel<EntityModel<Vehiculo>> porMarca(@PathVariable String marca) {
        return CollectionModel.of(service.buscarPorMarca(marca).stream().map(assembler::toModel).toList());
    }

    @GetMapping("/modelo/{modelo}")
    public CollectionModel<EntityModel<Vehiculo>> porModelo(@PathVariable String modelo) {
        return CollectionModel.of(service.buscarPorModelo(modelo).stream().map(assembler::toModel).toList());
    }

    @GetMapping("/anio/{anio}")
    public CollectionModel<EntityModel<Vehiculo>> porAnio(@PathVariable int anio) {
        return CollectionModel.of(service.buscarPorAnio(anio).stream().map(assembler::toModel).toList());
    }

    @GetMapping("/precio/{precio}")
    public CollectionModel<EntityModel<Vehiculo>> porPrecio(@PathVariable Double precio) {
        return CollectionModel.of(service.buscarPorPrecio(precio).stream().map(assembler::toModel).toList());
    }
}