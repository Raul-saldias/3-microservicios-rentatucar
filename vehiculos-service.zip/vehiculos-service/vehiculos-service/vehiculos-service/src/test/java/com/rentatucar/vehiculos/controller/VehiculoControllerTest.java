package com.rentatucar.vehiculos.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rentatucar.vehiculos.model.Vehiculo;
import com.rentatucar.vehiculos.service.VehiculoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VehiculoController.class)
@ActiveProfiles("test")
public class VehiculoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private VehiculoService vehiculoService;

    @Autowired
    private ObjectMapper objectMapper;

    private Vehiculo vehiculo;

    @BeforeEach
    void setUp() {
        vehiculo = new Vehiculo();
        vehiculo.setId(1L);
        vehiculo.setPlacaPatente("XYZ123");
        vehiculo.setMarca("Toyota");
        vehiculo.setModelo("Corolla");
        vehiculo.setAnio(2022);
        vehiculo.setPrecioPorDia(35000.0);
        vehiculo.setEstado("DISPONIBLE");
    }

    @Test
    void testRegistrarVehiculo() throws Exception {
        when(vehiculoService.registrarVehiculo(any())).thenReturn(vehiculo);

        mockMvc.perform(post("/vehiculos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(vehiculo)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.placaPatente").value("XYZ123"));
    }

    @Test
    void testObtenerVehiculoPorPlaca() throws Exception {
        when(vehiculoService.buscarPorPlaca("XYZ123")).thenReturn(vehiculo);

        mockMvc.perform(get("/vehiculos/placa/XYZ123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.marca").value("Toyota"));
    }

    @Test
    void testObtenerVehiculosPorEstado() throws Exception {
        when(vehiculoService.buscarPorEstado("DISPONIBLE")).thenReturn(List.of(vehiculo));

        mockMvc.perform(get("/vehiculos/estado/DISPONIBLE"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].estado").value("DISPONIBLE"));
    }

    @Test
    void testActualizarVehiculo() throws Exception {
        when(vehiculoService.actualizarVehiculo(eq(1L), any())).thenReturn(vehiculo);

        mockMvc.perform(put("/vehiculos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(vehiculo)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.modelo").value("Corolla"));
    }

    @Test
    void testEliminarVehiculo() throws Exception {
        doNothing().when(vehiculoService).eliminarPorId(1L);

        mockMvc.perform(delete("/vehiculos/1"))
                .andExpect(status().isNoContent());
    }
}