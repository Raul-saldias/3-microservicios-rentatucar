package com.rentatucar.vehiculos.service;

import com.rentatucar.vehiculos.model.Vehiculo;
import com.rentatucar.vehiculos.repository.VehiculoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class VehiculoServiceTest {

	@Mock
	private VehiculoRepository vehiculoRepository;

	@InjectMocks
	private VehiculoService vehiculoService;

	private Vehiculo vehiculo;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		vehiculo = new Vehiculo();
		vehiculo.setPlacaPatente("XYZ123");
		vehiculo.setMarca("Toyota");
		vehiculo.setModelo("Corolla");
		vehiculo.setAnio(2022);
		vehiculo.setPrecioPorDia(35000.0);
		vehiculo.setEstado("DISPONIBLE");
	}

	@Test
	void testRegistrarVehiculoNuevo() {
		when(vehiculoRepository.findByPlacaPatente("XYZ123")).thenReturn(Optional.empty());
		when(vehiculoRepository.save(any())).thenReturn(vehiculo);

		Vehiculo resultado = vehiculoService.registrarVehiculo(vehiculo);

		assertNotNull(resultado);
		assertEquals("XYZ123", resultado.getPlacaPatente());
	}

	@Test
	void testRegistrarVehiculoDuplicado() {
		when(vehiculoRepository.findByPlacaPatente("XYZ123")).thenReturn(Optional.of(vehiculo));

		RuntimeException ex = assertThrows(RuntimeException.class, () -> {
			vehiculoService.registrarVehiculo(vehiculo);
		});

		assertEquals("Ya existe un vehículo con esta placa patente.", ex.getMessage());
	}

	@Test
	void testActualizarEstadoVehiculo() {
		when(vehiculoRepository.findByPlacaPatente("XYZ123")).thenReturn(Optional.of(vehiculo));
		when(vehiculoRepository.save(any())).thenReturn(vehiculo);

		vehiculoService.actualizarEstadoVehiculo("XYZ123", "ARRENDADO");

		verify(vehiculoRepository).save(argThat(v -> v.getEstado().equals("ARRENDADO")));
	}

	@Test
	void testEliminarVehiculoPorPlaca() {
		when(vehiculoRepository.findByPlacaPatente("XYZ123")).thenReturn(Optional.of(vehiculo));

		boolean eliminado = vehiculoService.eliminarVehiculoPorPlaca("XYZ123");

		assertTrue(eliminado);
		verify(vehiculoRepository).delete(vehiculo);
	}
}