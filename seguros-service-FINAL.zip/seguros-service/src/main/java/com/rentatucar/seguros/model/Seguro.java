package com.rentatucar.seguros.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table (name="seguro")
@Data
@NoArgsConstructor
@AllArgsConstructor


public class Seguro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id_Contrato;

    @Column (unique = true, length = 6, nullable=false)
    private String Patente;

    @Column (nullable=false)
    private String id;

    @Column (nullable=false, length = 50)
    private String Tipo_Contrato;

    @Column (nullable=false)
    private Date Fecha_Inicio;

    @Column (nullable=false)
    private Date Fecha_Fin;

    @Column (nullable=false, length = 40)
    private String estado;

}

