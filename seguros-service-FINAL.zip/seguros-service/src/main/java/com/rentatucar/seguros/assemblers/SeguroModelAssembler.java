package com.rentatucar.seguros.assemblers;

import com.rentatucar.seguros.controller.SeguroControllerV2;
import com.rentatucar.seguros.model.Seguro;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class SeguroModelAssembler implements RepresentationModelAssembler<Seguro, EntityModel<Seguro>> {

    @Override
    public EntityModel<Seguro> toModel(Seguro seguro) {
        return EntityModel.of(seguro,
                linkTo(methodOn(SeguroControllerV2.class).getSeguroById(seguro.getId_Contrato())).withSelfRel(),
                linkTo(methodOn(SeguroControllerV2.class).getAllSeguros()).withRel("seguros"));
    }
}

