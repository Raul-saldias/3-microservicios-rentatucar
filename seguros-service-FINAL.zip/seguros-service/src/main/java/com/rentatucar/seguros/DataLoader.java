package com.rentatucar.seguros;

import com.rentatucar.seguros.model.*;
import com.rentatucar.seguros.repository.*;



import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {
    @Autowired
    private SeguroRepository seguroRepository;

    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        List<String>tiposContratos = Arrays.asList("BASICO","MEDIO","PRO 3.0");
        List<String>estado = Arrays.asList("VIGENTE ","PENDIENTE","VENCIDO");

        for (int i = 0; i<10; i++){
            Seguro seguro = new Seguro();
            seguro.setId(faker.idNumber().valid());
            seguro.setTipo_Contrato(tiposContratos.get(faker.random().nextInt(tiposContratos.size())));
            seguro.setEstado(estado.get(faker.random().nextInt(estado.size())));
            seguro.setPatente(faker.bothify("??####"));
            seguro.setFecha_Inicio(faker.date().past(30, TimeUnit.DAYS));
            seguro.setFecha_Fin(faker.date().future(60, TimeUnit.DAYS));
            seguroRepository.save(seguro);

        }


    }

}
