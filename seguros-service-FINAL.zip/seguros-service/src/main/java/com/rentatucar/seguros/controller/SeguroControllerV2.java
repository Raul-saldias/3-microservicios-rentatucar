package com.rentatucar.seguros.controller;

import com.rentatucar.seguros.assemblers.SeguroModelAssembler;
import com.rentatucar.seguros.model.Seguro;
import com.rentatucar.seguros.service.SeguroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/seguros")
public class SeguroControllerV2 {

    @Autowired
    private SeguroService seguroService;

    @Autowired
    private SeguroModelAssembler assembler;

    // GET: Todos los seguros con HATEOAS
    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<CollectionModel<EntityModel<Seguro>>> getAllSeguros() {
        List<EntityModel<Seguro>> seguros = seguroService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return ResponseEntity.ok(
                CollectionModel.of(seguros,
                        linkTo(methodOn(SeguroControllerV2.class).getAllSeguros()).withSelfRel()));
    }

    // GET: Seguro por ID_Contrato
    @GetMapping(value = "/{Id_Contrato}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Seguro>> getSeguroById(@PathVariable("Id_Contrato") Integer idContrato) {
        try {
            Seguro seguro = seguroService.findById(idContrato);
            return ResponseEntity.ok(assembler.toModel(seguro));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    // POST: Crear nuevo seguro
    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE, consumes = "application/json")
    public ResponseEntity<EntityModel<Seguro>> crearSeguro(@RequestBody Seguro seguro) {
        Seguro nuevoSeguro = seguroService.save(seguro);
        EntityModel<Seguro> seguroModel = assembler.toModel(nuevoSeguro);
        return ResponseEntity.status(HttpStatus.CREATED).body(seguroModel);
    }

    // PUT: Actualizar seguro por ID
    @PutMapping(value = "/{Id_Contrato}", produces = MediaTypes.HAL_JSON_VALUE, consumes = "application/json")
    public ResponseEntity<EntityModel<Seguro>> actualizarSeguro(
            @PathVariable("Id_Contrato") Integer idContrato,
            @RequestBody Seguro seguroActualizado) {
        try {
            Seguro existente = seguroService.findById(idContrato);
            if (existente == null) return ResponseEntity.notFound().build();

            existente.setPatente(seguroActualizado.getPatente());
            existente.setTipo_Contrato(seguroActualizado.getTipo_Contrato());
            existente.setFecha_Inicio(seguroActualizado.getFecha_Inicio());
            existente.setFecha_Fin(seguroActualizado.getFecha_Fin());
            existente.setEstado(seguroActualizado.getEstado());

            Seguro actualizado = seguroService.save(existente);
            return ResponseEntity.ok(assembler.toModel(actualizado));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // DELETE: Eliminar seguro por ID
    @DeleteMapping("/{Id_Contrato}")
    public ResponseEntity<Void> eliminarSeguro(@PathVariable("Id_Contrato") Integer idContrato) {
        try {
            seguroService.delete(idContrato);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
