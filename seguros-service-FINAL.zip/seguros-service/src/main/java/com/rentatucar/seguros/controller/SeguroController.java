package com.rentatucar.seguros.controller;

import com.rentatucar.seguros.model.Seguro;
import com.rentatucar.seguros.service.SeguroService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/seguros")
@Tag(name = "Seguros", description = "Operaciones relacionadas con los seguros de los autos con CRUD y sin HATEOAS")
public class SeguroController {

    @Autowired
    private SeguroService seguroService;

    @GetMapping
    @Operation(summary = "Obtiene todos los seguros", description = "Recupera el listado completo de seguros disponibles")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de seguros encontrada",
                    content = @Content(
                            mediaType = "application/json",
                            array = @ArraySchema(schema = @Schema(implementation = Seguro.class))
                    )),
            @ApiResponse(responseCode = "204", description = "No hay seguros disponibles")
    })
    public ResponseEntity<List<Seguro>> listar() {
        List<Seguro> seguros = seguroService.findAll();
        if (seguros.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(seguros);
    }

    @PostMapping
    @Operation(summary = "Crea un nuevo seguro", description = "Registra un nuevo seguro en el sistema")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Seguro creado exitosamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Seguro.class)
                    )),
            @ApiResponse(responseCode = "400", description = "Datos inválidos enviados")
    })
    public ResponseEntity<Seguro> guardar(
            @RequestBody(
                    description = "Objeto Seguro a crear",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Seguro.class),
                            examples = @ExampleObject(
                                    name = "Ejemplo de Seguro",
                                    summary = "Seguro básico",
                                    value = """
                                            {
                                              "id": 1,
                                              "patente": "XYZ987",
                                              "tipo_Contrato": "Anual",
                                              "fecha_Inicio": "2025-01-01",
                                              "fecha_Fin": "2026-01-01",
                                              "estado": "Activo"
                                            }
                                            """
                            )
                    )
            )
            @org.springframework.web.bind.annotation.RequestBody Seguro seguro
    ) {
        Seguro secureNew = seguroService.save(seguro);
        return ResponseEntity.status(HttpStatus.CREATED).body(secureNew);
    }

    @GetMapping("/{Id_Contrato}")
    @Operation(summary = "Obtiene un seguro por ID", description = "Busca y devuelve un seguro por su ID de contrato")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Seguro encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Seguro.class),
                            examples = @ExampleObject(
                                    name = "Seguro ejemplo",
                                    summary = "activo",
                                    value = """
                                            {
                                              "id": 2,
                                              "patente": "ABC123",
                                              "tipo_Contrato": "Mensual",
                                              "fecha_Inicio": "2025-07-01",
                                              "fecha_Fin": "2025-08-01",
                                              "estado": "Activo"
                                            }
                                            """
                            )
                    )),
            @ApiResponse(responseCode = "404", description = "Seguro no encontrado")
    })
    public ResponseEntity<Seguro> buscar(@PathVariable("Id_Contrato") Integer idContrato) {
        try {
            Seguro seguro = seguroService.findById(idContrato);
            return ResponseEntity.ok(seguro);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{Id_Contrato}")
    @Operation(summary = "Actualiza un seguro", description = "Modifica los datos de un seguro existente por su ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Seguro actualizado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Seguro.class)
                    )),
            @ApiResponse(responseCode = "404", description = "Seguro no encontrado"),
            @ApiResponse(responseCode = "500", description = "Error interno al actualizar el seguro")
    })
    public ResponseEntity<Seguro> actualizar(
            @PathVariable("Id_Contrato") Integer idContrato,
            @org.springframework.web.bind.annotation.RequestBody Seguro seguro) {
        try {
            Seguro sec = seguroService.findById(idContrato);
            if (sec == null) return ResponseEntity.notFound().build();

            sec.setPatente(seguro.getPatente());
            sec.setId(seguro.getId());
            sec.setTipo_Contrato(seguro.getTipo_Contrato());
            sec.setFecha_Inicio(seguro.getFecha_Inicio());
            sec.setFecha_Fin(seguro.getFecha_Fin());
            sec.setEstado(seguro.getEstado());

            Seguro actualizado = seguroService.save(sec);
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{Id_Contrato}")
    @Operation(summary = "Elimina un seguro", description = "Elimina un seguro por su ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Seguro eliminado correctamente"),
            @ApiResponse(responseCode = "404", description = "Seguro no encontrado")
    })
    public ResponseEntity<Void> eliminar(@PathVariable("Id_Contrato") Integer idContrato) {
        try {
            seguroService.delete(idContrato);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}

