package com.rentatucar.seguros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegurosServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegurosServiceApplication.class, args);
	}

}
