package com.rentatucar.seguros.service;

import com.rentatucar.seguros.model.Seguro;
import com.rentatucar.seguros.repository.SeguroRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional

public class SeguroService {

    @Autowired
    private SeguroRepository seguroRepository;
    public List<Seguro> findAll() {
        return seguroRepository.findAll();
    }
    public Seguro findById(Integer id) {
        return seguroRepository.findById(id).orElse(null);
    }
    public Seguro save(Seguro seguro){return seguroRepository.save(seguro);}
    public void delete(Integer id){seguroRepository.deleteById(id);}


}