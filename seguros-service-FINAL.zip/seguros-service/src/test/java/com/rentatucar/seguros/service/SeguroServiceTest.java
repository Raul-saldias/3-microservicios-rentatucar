package com.rentatucar.seguros.service;

import com.rentatucar.seguros.model.Seguro;
import com.rentatucar.seguros.repository.SeguroRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

@ExtendWith(MockitoExtension.class)
public class SeguroServiceTest {

    @Mock
    private SeguroRepository seguroRepository;

    @InjectMocks
    private SeguroService seguroService;

    private Seguro seguro;

    @BeforeEach
    void setUp() {
        seguro = new Seguro();
        seguro.setId_Contrato(1);
        seguro.setPatente("XYZ123");
        seguro.setId("SEG001");
        seguro.setTipo_Contrato("Anual");
        seguro.setFecha_Inicio(getDate(2025, Calendar.JANUARY, 1));
        seguro.setFecha_Fin(getDate(2026, Calendar.JANUARY, 1));
        seguro.setEstado("Activo");
    }

    // Método utilitario para crear java.util.Date fácilmente
    private Date getDate(int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day, 0, 0, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    @Test
    void testGuardarSeguro() {
        when(seguroRepository.save(any(Seguro.class))).thenReturn(seguro);

        Seguro result = seguroService.save(seguro);

        assertNotNull(result);
        assertEquals("XYZ123", result.getPatente());
        verify(seguroRepository, times(1)).save(seguro);
    }

    @Test
    void testBuscarPorId() {
        when(seguroRepository.findById(1)).thenReturn(Optional.of(seguro));

        Seguro result = seguroService.findById(1);

        assertNotNull(result);
        assertEquals(1, result.getId_Contrato());
        verify(seguroRepository, times(1)).findById(1);
    }

    @Test
    void testBuscarTodos() {
        Seguro otroSeguro = new Seguro();
        otroSeguro.setId_Contrato(2);
        otroSeguro.setPatente("ABC987");
        otroSeguro.setId("SEG002");
        otroSeguro.setTipo_Contrato("Mensual");
        otroSeguro.setFecha_Inicio(getDate(2025, Calendar.FEBRUARY, 1));
        otroSeguro.setFecha_Fin(getDate(2025, Calendar.MARCH, 1));
        otroSeguro.setEstado("Inactivo");

        List<Seguro> listaMock = Arrays.asList(seguro, otroSeguro);
        when(seguroRepository.findAll()).thenReturn(listaMock);

        List<Seguro> result = seguroService.findAll();

        assertEquals(2, result.size());
        verify(seguroRepository, times(1)).findAll();
    }

    @Test
    void testEliminar() {
        doNothing().when(seguroRepository).deleteById(1);

        seguroService.delete(1);

        verify(seguroRepository, times(1)).deleteById(1);
    }
}

