package com.rentatucar.seguros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegurosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
