package com.rentatucar.seguros.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rentatucar.seguros.model.Seguro;
import com.rentatucar.seguros.service.SeguroService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SeguroController.class)
@ActiveProfiles("test")
public class SeguroControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SeguroService seguroService;

    @Autowired
    private ObjectMapper objectMapper;

    private Seguro seguro;

    @BeforeEach
    void setUp() {
        seguro = new Seguro();
        seguro.setId_Contrato(1);
        seguro.setPatente("AB1234");
        seguro.setId("SEG001");
        seguro.setTipo_Contrato("PRO 3.0");
        seguro.setFecha_Inicio(getDate(2025, Calendar.JUNE, 1));
        seguro.setFecha_Fin(getDate(2026, Calendar.JUNE, 1));
        seguro.setEstado("VENCIDO");
    }

    private Date getDate(int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day, 0, 0, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    @Test
    void testRegistrarSeguro() throws Exception {
        when(seguroService.save(any(Seguro.class))).thenReturn(seguro);

        mockMvc.perform(post("/api/v1/seguros")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(seguro)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.patente").value("AB1234"))
                .andExpect(jsonPath("$.estado").value("VENCIDO"));
    }

    @Test
    void testListarSeguros() throws Exception {
        when(seguroService.findAll()).thenReturn(List.of(seguro));

        mockMvc.perform(get("/api/v1/seguros"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].patente").value("AB1234"))
                .andExpect(jsonPath("$[0].tipo_Contrato").value("PRO 3.0"));
    }

    @Test
    void testBuscarPorId() throws Exception {
        when(seguroService.findById(1)).thenReturn(seguro);

        mockMvc.perform(get("/api/v1/seguros/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("SEG001"))
                .andExpect(jsonPath("$.patente").value("AB1234"));
    }

    @Test
    void testActualizarSeguro() throws Exception {
        // Simular que ya existe
        when(seguroService.findById(1)).thenReturn(seguro);

        // Simular retorno actualizado
        Seguro actualizado = new Seguro();
        actualizado.setId_Contrato(1);
        actualizado.setPatente("CD5678");
        actualizado.setId("SEG001");
        actualizado.setTipo_Contrato("FULL 4.0");
        actualizado.setFecha_Inicio(getDate(2025, Calendar.AUGUST, 1));
        actualizado.setFecha_Fin(getDate(2026, Calendar.AUGUST, 1));
        actualizado.setEstado("ACTIVO");

        when(seguroService.save(any(Seguro.class))).thenReturn(actualizado);

        mockMvc.perform(put("/api/v1/seguros/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(actualizado)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.patente").value("CD5678"))
                .andExpect(jsonPath("$.estado").value("ACTIVO"));
    }

    @Test
    void testEliminarSeguro() throws Exception {
        doNothing().when(seguroService).delete(1);

        mockMvc.perform(delete("/api/v1/seguros/1"))
                .andExpect(status().isNoContent());
    }
}
